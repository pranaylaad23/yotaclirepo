import "./App.css";
import AppRoutes from "./route/route";

function App() {
  return (
    <div className="App">
      <AppRoutes />
    </div>
  );
}

export default App;
