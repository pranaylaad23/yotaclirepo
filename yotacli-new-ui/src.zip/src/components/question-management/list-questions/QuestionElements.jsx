import React from 'react';

const QuestionElements = ({children})=>{
    return (
        <div class="accordion" id="accordionExample">
            {children}
        </div>
    );
};
export default QuestionElements ;