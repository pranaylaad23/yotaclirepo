import React from "react";

const UpdateAssocoate = () => {
  return (
    <div>
      <h>Hello</h>
    </div>
  );
};

export default UpdateAssocoate;
