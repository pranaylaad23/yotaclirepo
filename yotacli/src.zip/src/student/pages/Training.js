import React from 'react';

const Training = () => {
    return (
        <div className="training">
            <h1>TRAINING</h1>
            <h3>Java</h3>
            <h3>React</h3>
        </div>
    );
};

export default Training;