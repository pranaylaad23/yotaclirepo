import React from 'react';

const TrainingSummary = () => {
    return (
        <div className="trainingsummary">
            <h1>TRAINING SUMMARY </h1>
            <h4>Java, AWS & React JS</h4>
           
        </div>
    );
};
export default TrainingSummary;
