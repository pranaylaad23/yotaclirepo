import React from 'react';

export const Signout = () => {
    return (
        <div className="signout">
        <h1>Signing Out</h1>
    </div>
    );
};