import React from 'react';

const TestLinks = () => {
    return (
        <div className="testlinks">
            <h1>TEST LINKS</h1>
        </div>
    );
};
export default TestLinks;
