import React from "react";

const Footer = () => {
  return (
    <div className="foot">
      <div >
        <p>
          Copyright © 2022-2023 YOTA App Pvt.Ltd. All right reserved. Created by MURALI
        </p>
      </div>
    </div>
  );
};

export default Footer;

