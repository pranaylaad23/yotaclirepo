import React from 'react';

const Analytics = () => {
    return (
        <div>
            <h1>ANALYTICS</h1>
            </div>
    );
};

export default Analytics;
